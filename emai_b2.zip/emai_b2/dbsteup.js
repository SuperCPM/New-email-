const pool = require('./db');

// Insert sample users
const insertSampleUsers = () => {
  const users = [
    { full_name: 'John Doe', email: 'john@example.com', password: 'password1' },
    { full_name: 'Jane Smith', email: 'jane@example.com', password: 'password2' },
    // Add more sample users as needed
  ];

  const query = 'INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)';
  users.forEach((user) => {
    pool.query(query, [user.full_name, user.email, user.password], (err, results) => {
      if (err) {
        console.error('Error inserting sample user:', err);
      } else {
        console.log('Inserted sample user with ID:', results.insertId);
      }
    });
  });
};

// Insert sample emails
const insertSampleEmails = () => {
  const emails = [
    { sender_id: 1, receiver_id: 2, subject: 'Test Email 1', body: 'Hello Jane!', file_path: null },
    { sender_id: 2, receiver_id: 1, subject: 'Test Email 2', body: 'Hi John!', file_path: null },
    // Add more sample emails as needed
  ];

  const query =
    'INSERT INTO emails (sender_id, receiver_id, subject, body, file_path) VALUES (?, ?, ?, ?, ?)';
  emails.forEach((email) => {
    pool.query(query, [email.sender_id, email.receiver_id, email.subject, email.body, email.file_path], (err, results) => {
      if (err) {
        console.error('Error inserting sample email:', err);
      } else {
        console.log('Inserted sample email with ID:', results.insertId);
      }
    });
  });
};

// Insert sample data on application start
insertSampleUsers();
insertSampleEmails();
